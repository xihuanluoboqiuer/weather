/**
  * Copyright 2021 json.cn 
  */
package com.aye.weather.Bean;

/**
 * Auto-generated: 2021-09-14 21:11:55
 *
 * @author json.cn (i@json.cn)
 * @website http://www.json.cn/java2pojo/
 */
public class Alarm {

    private String alarm_type;
    private String alarm_level;
    private String alarm_content;
    public void setAlarm_type(String alarm_type) {
         this.alarm_type = alarm_type;
     }
     public String getAlarm_type() {
         return alarm_type;
     }

    public void setAlarm_level(String alarm_level) {
         this.alarm_level = alarm_level;
     }
     public String getAlarm_level() {
         return alarm_level;
     }

    public void setAlarm_content(String alarm_content) {
         this.alarm_content = alarm_content;
     }
     public String getAlarm_content() {
         return alarm_content;
     }
}