/**
  * Copyright 2021 json.cn 
  */
package com.aye.weather.Bean;

/**
 * Auto-generated: 2021-09-14 21:11:55
 *
 * @author json.cn (i@json.cn)
 * @website http://www.json.cn/java2pojo/
 */
/*
hours : "19时"
wea : "阴"
wea_img : "yin"
tem : "22"
win : "东北风"
win_speed : "<3级"
 */
public class Hours {

    private String hours;
    private String wea;
    private String wea_img;
    private String tem;
    private String win;
    private String win_speed;
    public void setHours(String hours) {
         this.hours = hours;
     }
     public String getHours() {
         return hours;
     }

    public void setWea(String wea) {
         this.wea = wea;
     }
     public String getWea() {
         return wea;
     }

    public void setWea_img(String wea_img) {
         this.wea_img = wea_img;
     }
     public String getWea_img() {
         return wea_img;
     }

    public void setTem(String tem) {
         this.tem = tem;
     }
     public String getTem() {
         return tem;
     }

    public void setWin(String win) {
         this.win = win;
     }
     public String getWin() {
         return win;
     }

    public void setWin_speed(String win_speed) {
         this.win_speed = win_speed;
     }
     public String getWin_speed() {
         return win_speed;
     }
}